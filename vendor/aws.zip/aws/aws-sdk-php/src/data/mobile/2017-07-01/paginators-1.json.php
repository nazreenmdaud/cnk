<?php
// This file was auto-generated from sdk-root/src/data/mobile/2017-07-01/paginators-1.json
return [ 'pagination' => [ 'ListBundles' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListProjects' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
